﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3library
{
    public partial class Frmbooks : Form
    {
        
        SqlConnection con = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\LMS.mdf;Integrated Security = True");
        //Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C: \Users\udaya\source\repos\Esoft Project\LMS.mdf;Integrated Security=True
        SqlCommand com;
        SqlDataReader dr;
        public Frmbooks()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Frmbooks_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string sqlinsert = "insert into Books(BookID,BookName,Author,Publisher,PublishedDate)values('" + txtbid.Text + "','" + txtbookname.Text + "','" + txtauthor.Text + "','" + txtpublisher.Text + "','" + dtpDOP.Text + "')";
                com = new SqlCommand(sqlinsert, con);
                com.ExecuteNonQuery();
                MessageBox.Show("New book added successfully");

                txtbid.Clear();
                txtbookname.Clear();
                txtauthor.Clear();
                txtpublisher.Text = "";
                dtpDOP.Text = "";
                txtbid.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show("A book is already registered under this Book ID"+ex);
                txtbookname.Clear();
                txtauthor.Clear();
                txtbid.Clear();
                txtpublisher.Clear();
                dtpDOP.Text = "";
                txtbid.Focus();
            }
            finally
            {
                con.Close();
            }
        }

        private void btnclearall_Click(object sender, EventArgs e)
        {
            txtbookname.Clear();
            txtauthor.Clear();
            txtbid.Clear();
            txtpublisher.Clear();
            dtpDOP.Text = "";
            txtbid.Focus();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Update_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string sqlupdate = "update Books set BookName='"+txtbookname.Text+"',Author='" + txtauthor.Text + "',Publisher='" + txtpublisher.Text + "',PublishedDate='" + dtpDOP.Text + "' where BookID='" + txtbid.Text + "'";
                com = new SqlCommand(sqlupdate, con);
                com.ExecuteNonQuery();
                MessageBox.Show("Updated successfully");

                txtbid.Clear();
                txtbookname.Clear();
                txtauthor.Clear();
                txtpublisher.Text = "";
                dtpDOP.Text = "";
                txtbid.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while updating!"+ex);
                txtbid.Clear();
                txtbookname.Clear();
                txtauthor.Clear();
                txtpublisher.Text = "";
                dtpDOP.Text = "";
                txtbid.Focus();
            }
            finally
            {
                con.Close();
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string sqldelete = "delete from Books where BookID='" + txtbid.Text + "'";
                com = new SqlCommand(sqldelete, con);
                com.ExecuteNonQuery();
                MessageBox.Show("Record deleted successfully");

                txtbid.Clear();
                txtbookname.Clear();
                txtauthor.Clear();
                txtpublisher.Text = "";
                dtpDOP.Text = "";
                txtbid.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show("There's no book registered under this Book ID"+ex);
                txtbid.Clear();
                txtbid.Focus();
            }
            finally
            {
                con.Close();
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string ID = txtBookID.Text;
                MessageBox.Show(txtBookID.Text);
                //  string sqlsearch = "SELECT* FROM Books WHERE BookID='" + txtBookID.Text + "'";
                com = new SqlCommand("SELECT* FROM Books WHERE BookID='" + txtBookID.Text + "'", con);
               // SqlCommand com = new SqlCommand(sqlsearch, con);
                // SqlDataReader r = com.ExecuteReader();
                
                dr=com.ExecuteReader();
                dr.Read();
                //{
                    txtbid.Text = dr[0].ToString();
                    txtbookname.Text = dr[1].ToString();
                    txtauthor.Text = dr[2].ToString();
                    txtpublisher.Text = dr[3].ToString();
                    dtpDOP.Text = dr[4].ToString();
              //  }

              //  if (dr.Read()) 
               // {
                  //  txtbid.Text = dr[0].ToString();
                  //  txtbookname.Text = dr[1].ToString();
                  //  txtauthor.Text = dr[2].ToString();
                  //  txtpublisher.Text = dr[3].ToString();
                  //  dtpDOP.Text = dr[4].ToString();
               // }
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message );
                MessageBox.Show("There's no book registered under this BookID"+er);
                txtBookID.Clear();
                txtBookID.Focus();
            }
            finally
            {
                con.Close();
            }
        }

        private void txtbookID_TextChanged(object sender, EventArgs e)
        {

        }

        private void dtbDOP_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtpublisher_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtbid_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
