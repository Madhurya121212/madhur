﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WindowsFormsApp3library
{
    public partial class Frmbooksearch : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\LMS.mdf;Integrated Security = True");
        SqlCommand com;
        public Frmbooksearch()
        {
            InitializeComponent();
        }

        private void Frmbooksearch_Load(object sender, EventArgs e)
        {

        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txtbookname.Clear();
            txtauthor.Clear();
            txtbookid.Clear();
            txtpublishers.Clear();
            dtpdop.Text = "";
            txtbookid.Focus();
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Logging out", "Continuing", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            Frmlogout logout = new Frmlogout();
            this.Hide();
            logout.Show();
        }

        private void btnnamesearch_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string ID = txtbooksearch.Text;
                string sqlsearch = "SELECT* FROM Books WHERE BookName='" + txtbooksearch.Text + "'";
                SqlCommand com = new SqlCommand(sqlsearch, con);
                SqlDataReader r = com.ExecuteReader();
                if (r.Read())
                {
                    txtbookid.Text = r[0].ToString();
                    txtbookname.Text = r[1].ToString();
                    txtauthor.Text = r[2].ToString();
                    txtpublishers.Text = r[3].ToString();
                    dtpdop.Text = r[4].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("This book doesn't exist."+ex);
                txtbooksearch.Clear();
                txtbooksearch.Focus();
            }
            finally
            {
                con.Close();
            }
        }

        private void btnauthorsearch_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void txtauthorsearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtbooksearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void bookname_Click(object sender, EventArgs e)
        {

        }
    }
}
