﻿
namespace WindowsFormsApp3library
{
    partial class FrmStart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmStart));
            this.btnstart = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lMSDataSettest = new WindowsFormsApp3library.LMSDataSettest();
            this.lMSDataSettestBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lMSDataSettestBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.booksBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.booksTableAdapter = new WindowsFormsApp3library.LMSDataSettestTableAdapters.BooksTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.lMSDataSettest)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lMSDataSettestBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lMSDataSettestBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.booksBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnstart
            // 
            this.btnstart.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnstart.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnstart.Location = new System.Drawing.Point(329, 268);
            this.btnstart.Name = "btnstart";
            this.btnstart.Size = new System.Drawing.Size(120, 52);
            this.btnstart.TabIndex = 0;
            this.btnstart.Text = "Start";
            this.btnstart.UseVisualStyleBackColor = false;
            this.btnstart.Click += new System.EventHandler(this.btnlogin_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Font = new System.Drawing.Font("Bernard MT Condensed", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(83, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(620, 76);
            this.label1.TabIndex = 1;
            this.label1.Text = "Leeds Children\'s Library";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lMSDataSettest
            // 
            this.lMSDataSettest.DataSetName = "LMSDataSettest";
            this.lMSDataSettest.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lMSDataSettestBindingSource
            // 
            this.lMSDataSettestBindingSource.DataSource = this.lMSDataSettest;
            this.lMSDataSettestBindingSource.Position = 0;
            // 
            // lMSDataSettestBindingSource1
            // 
            this.lMSDataSettestBindingSource1.DataSource = this.lMSDataSettest;
            this.lMSDataSettestBindingSource1.Position = 0;
            // 
            // booksBindingSource
            // 
            this.booksBindingSource.DataMember = "Books";
            this.booksBindingSource.DataSource = this.lMSDataSettestBindingSource1;
            // 
            // booksTableAdapter
            // 
            this.booksTableAdapter.ClearBeforeFill = true;
            // 
            // FrmStart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnstart);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmStart";
            this.Text = "Start";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.lMSDataSettest)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lMSDataSettestBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lMSDataSettestBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.booksBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnstart;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.BindingSource lMSDataSettestBindingSource;
        private LMSDataSettest lMSDataSettest;
        private System.Windows.Forms.BindingSource lMSDataSettestBindingSource1;
        private System.Windows.Forms.BindingSource booksBindingSource;
        private LMSDataSettestTableAdapters.BooksTableAdapter booksTableAdapter;
    }
}

