﻿
namespace WindowsFormsApp3library
{
    partial class Frmbooksearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frmbooksearch));
            this.btnnamesearch = new System.Windows.Forms.Button();
            this.txtbooksearch = new System.Windows.Forms.TextBox();
            this.btnclear = new System.Windows.Forms.Button();
            this.btnlogout = new System.Windows.Forms.Button();
            this.lblauthor = new System.Windows.Forms.Label();
            this.bookid = new System.Windows.Forms.Label();
            this.bookname = new System.Windows.Forms.Label();
            this.publisher = new System.Windows.Forms.Label();
            this.publisheddate = new System.Windows.Forms.Label();
            this.txtbookid = new System.Windows.Forms.TextBox();
            this.txtpublishers = new System.Windows.Forms.TextBox();
            this.txtauthor = new System.Windows.Forms.TextBox();
            this.txtbookname = new System.Windows.Forms.TextBox();
            this.dtpdop = new System.Windows.Forms.DateTimePicker();
            this.Note = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnnamesearch
            // 
            this.btnnamesearch.Font = new System.Drawing.Font("Lucida Bright", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnamesearch.Location = new System.Drawing.Point(60, 49);
            this.btnnamesearch.Margin = new System.Windows.Forms.Padding(4);
            this.btnnamesearch.Name = "btnnamesearch";
            this.btnnamesearch.Size = new System.Drawing.Size(219, 51);
            this.btnnamesearch.TabIndex = 0;
            this.btnnamesearch.Text = "Search by Book Name";
            this.btnnamesearch.UseVisualStyleBackColor = true;
            this.btnnamesearch.Click += new System.EventHandler(this.btnnamesearch_Click);
            // 
            // txtbooksearch
            // 
            this.txtbooksearch.Location = new System.Drawing.Point(362, 75);
            this.txtbooksearch.Margin = new System.Windows.Forms.Padding(4);
            this.txtbooksearch.Name = "txtbooksearch";
            this.txtbooksearch.Size = new System.Drawing.Size(318, 25);
            this.txtbooksearch.TabIndex = 2;
            this.txtbooksearch.TextChanged += new System.EventHandler(this.txtbooksearch_TextChanged);
            // 
            // btnclear
            // 
            this.btnclear.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclear.Location = new System.Drawing.Point(99, 417);
            this.btnclear.Margin = new System.Windows.Forms.Padding(4);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(180, 56);
            this.btnclear.TabIndex = 4;
            this.btnclear.Text = "Clear";
            this.btnclear.UseVisualStyleBackColor = true;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // btnlogout
            // 
            this.btnlogout.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlogout.Location = new System.Drawing.Point(722, 410);
            this.btnlogout.Margin = new System.Windows.Forms.Padding(4);
            this.btnlogout.Name = "btnlogout";
            this.btnlogout.Size = new System.Drawing.Size(196, 63);
            this.btnlogout.TabIndex = 5;
            this.btnlogout.Text = "Log Out";
            this.btnlogout.UseVisualStyleBackColor = true;
            this.btnlogout.Click += new System.EventHandler(this.btnlogout_Click);
            // 
            // lblauthor
            // 
            this.lblauthor.AutoSize = true;
            this.lblauthor.Font = new System.Drawing.Font("Lucida Calligraphy", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblauthor.Location = new System.Drawing.Point(60, 250);
            this.lblauthor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblauthor.Name = "lblauthor";
            this.lblauthor.Size = new System.Drawing.Size(60, 17);
            this.lblauthor.TabIndex = 6;
            this.lblauthor.Text = "Author";
            // 
            // bookid
            // 
            this.bookid.AutoSize = true;
            this.bookid.Font = new System.Drawing.Font("Lucida Calligraphy", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookid.Location = new System.Drawing.Point(60, 140);
            this.bookid.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bookid.Name = "bookid";
            this.bookid.Size = new System.Drawing.Size(65, 17);
            this.bookid.TabIndex = 7;
            this.bookid.Text = "Book ID";
            // 
            // bookname
            // 
            this.bookname.AutoSize = true;
            this.bookname.Font = new System.Drawing.Font("Lucida Calligraphy", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookname.Location = new System.Drawing.Point(60, 194);
            this.bookname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bookname.Name = "bookname";
            this.bookname.Size = new System.Drawing.Size(88, 17);
            this.bookname.TabIndex = 8;
            this.bookname.Text = "Book Name";
            this.bookname.Click += new System.EventHandler(this.bookname_Click);
            // 
            // publisher
            // 
            this.publisher.AutoSize = true;
            this.publisher.Font = new System.Drawing.Font("Lucida Calligraphy", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.publisher.Location = new System.Drawing.Point(60, 309);
            this.publisher.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.publisher.Name = "publisher";
            this.publisher.Size = new System.Drawing.Size(79, 17);
            this.publisher.TabIndex = 9;
            this.publisher.Text = "Publishers";
            // 
            // publisheddate
            // 
            this.publisheddate.AutoSize = true;
            this.publisheddate.Font = new System.Drawing.Font("Lucida Calligraphy", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.publisheddate.Location = new System.Drawing.Point(60, 367);
            this.publisheddate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.publisheddate.Name = "publisheddate";
            this.publisheddate.Size = new System.Drawing.Size(137, 17);
            this.publisheddate.TabIndex = 10;
            this.publisheddate.Text = "Date of Publishing";
            // 
            // txtbookid
            // 
            this.txtbookid.Font = new System.Drawing.Font("Lucida Calligraphy", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbookid.Location = new System.Drawing.Point(362, 134);
            this.txtbookid.Name = "txtbookid";
            this.txtbookid.Size = new System.Drawing.Size(318, 29);
            this.txtbookid.TabIndex = 11;
            this.txtbookid.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtpublishers
            // 
            this.txtpublishers.Location = new System.Drawing.Point(362, 301);
            this.txtpublishers.Name = "txtpublishers";
            this.txtpublishers.Size = new System.Drawing.Size(318, 25);
            this.txtpublishers.TabIndex = 12;
            // 
            // txtauthor
            // 
            this.txtauthor.Location = new System.Drawing.Point(362, 247);
            this.txtauthor.Name = "txtauthor";
            this.txtauthor.Size = new System.Drawing.Size(318, 25);
            this.txtauthor.TabIndex = 14;
            // 
            // txtbookname
            // 
            this.txtbookname.Location = new System.Drawing.Point(362, 186);
            this.txtbookname.Name = "txtbookname";
            this.txtbookname.Size = new System.Drawing.Size(318, 25);
            this.txtbookname.TabIndex = 15;
            // 
            // dtpdop
            // 
            this.dtpdop.Location = new System.Drawing.Point(362, 359);
            this.dtpdop.Name = "dtpdop";
            this.dtpdop.Size = new System.Drawing.Size(318, 25);
            this.dtpdop.TabIndex = 16;
            // 
            // Note
            // 
            this.Note.AutoSize = true;
            this.Note.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Note.Font = new System.Drawing.Font("Lucida Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Note.Location = new System.Drawing.Point(33, 555);
            this.Note.Name = "Note";
            this.Note.Size = new System.Drawing.Size(437, 15);
            this.Note.TabIndex = 17;
            this.Note.Text = "Note=Every word in the book name should start with a capital letter";
            // 
            // Frmbooksearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1011, 611);
            this.Controls.Add(this.Note);
            this.Controls.Add(this.dtpdop);
            this.Controls.Add(this.txtbookname);
            this.Controls.Add(this.txtauthor);
            this.Controls.Add(this.txtpublishers);
            this.Controls.Add(this.txtbookid);
            this.Controls.Add(this.publisheddate);
            this.Controls.Add(this.publisher);
            this.Controls.Add(this.bookname);
            this.Controls.Add(this.bookid);
            this.Controls.Add(this.lblauthor);
            this.Controls.Add(this.btnlogout);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.txtbooksearch);
            this.Controls.Add(this.btnnamesearch);
            this.Font = new System.Drawing.Font("Lucida Calligraphy", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Frmbooksearch";
            this.Text = "Book Search";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Frmbooksearch_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnnamesearch;
        private System.Windows.Forms.TextBox txtbooksearch;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.Button btnlogout;
        private System.Windows.Forms.Label lblauthor;
        private System.Windows.Forms.Label bookid;
        private System.Windows.Forms.Label bookname;
        private System.Windows.Forms.Label publisher;
        private System.Windows.Forms.Label publisheddate;
        private System.Windows.Forms.TextBox txtbookid;
        private System.Windows.Forms.TextBox txtpublishers;
        private System.Windows.Forms.TextBox txtauthor;
        private System.Windows.Forms.TextBox txtbookname;
        private System.Windows.Forms.DateTimePicker dtpdop;
        private System.Windows.Forms.Label Note;
    }
}