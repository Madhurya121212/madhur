﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp3library
{
    public partial class Frmlogin : Form
    {
        public Frmlogin()
        {
            InitializeComponent();
        }
        /*string us = ("Book Manager");
        string pw = ("Bookworm");*/
        private void btnlogin_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Librarian" && txtPW.Text == "Admin")
            {
                MessageBox.Show("You are successfully logged in");
                txtPW.Clear();
                comboBox1.Text="";
                {
                    Frmmenuma Frmmenu = new Frmmenuma();
                    this.Hide();
                    Frmmenu.Show();
                }
            }
            else if (comboBox1.Text == "Member" && txtPW.Text == "User")
            {
                MessageBox.Show("You are successfully logged in");
                comboBox1.Text="";
                txtPW.Clear();
                 {
                    Frmbooksearch search = new Frmbooksearch();
                    this.Hide();
                    search.Show();
                }
            }
            else
            {
                MessageBox.Show("Incorrect username or password");
                comboBox1.Text = "";
                txtPW.Clear();
            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Logging out","Continuing",MessageBoxButtons.OK,MessageBoxIcon.Asterisk);
            Frmlogout logout = new Frmlogout();
            this.Hide();
            logout.Show();
        }

        private void username_Click(object sender, EventArgs e)
        {

        }

        private void password_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtPW_TextChanged(object sender, EventArgs e)
        {
      
        }

        private void Frmlogin_Load(object sender, EventArgs e)
        {
            this.Hide();
            
        }
    }
}
