﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3library
{
    public partial class Frmcal : Form
    {
        public Frmcal()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Fine_Click(object sender, EventArgs e)
        {

        }

        private void Totfine_Click(object sender, EventArgs e)
        {

        }
        int nodays, fine, totfine;

        private void btnlogout_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You are logging out", "Continuing", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            Frmlogout logout = new Frmlogout();
            this.Hide();
            logout.Show();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Frmcal_Load(object sender, EventArgs e)
        {

        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txtnodays.Clear();
            txtfine.Clear();
            txttotfine.Clear();
        }

        private void btntotal_Click(object sender, EventArgs e)
        {
            nodays = int.Parse(txtnodays.Text);
            fine = int.Parse(txtfine.Text);
            totfine =nodays*fine;
            txttotfine.Text = totfine.ToString();
        }
    }
}
