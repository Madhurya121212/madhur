﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp3library
{
    public partial class Frmmember : Form
    {
        
        SqlConnection con = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\LMS.mdf;Integrated Security = True");
        SqlCommand com;
        public Frmmember()
        {
            InitializeComponent();
        }

        private void Frmmember_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnclearall_Click(object sender, EventArgs e)
        {
            txtID.Clear();
            txtname.Clear();
            txtaddress.Clear();
            txtID.Clear();
            DTPDOB.Text="";
            DTPDOR.Text = "";
            txtID.Focus();
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string sqlinsert = "insert into Members(MemberID,Name,Address,DOB,DOR)values('" + txtID.Text + "','" + txtname.Text + "','" + txtaddress.Text + "','" + DTPDOB.Text + "','" + DTPDOR.Text + "')";
                com = new SqlCommand(sqlinsert, con);
                com.ExecuteNonQuery();
                MessageBox.Show("New member registered successfully!");

                txtID.Clear();
                txtname.Clear();
                txtaddress.Clear();
                txtID.Clear();
                DTPDOB.Text = "";
                DTPDOR.Text = "";
                txtID.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show("A member is already registered under this Member ID"+ex);

                txtname.Clear();
                txtaddress.Clear();
                txtID.Clear();
                DTPDOB.Text = "";
                DTPDOR.Text = "";
                txtID.Focus();

            }
            finally
            {
                con.Close();
            }
        }

        private void txtname_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtaddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void DTPDOB_ValueChanged(object sender, EventArgs e)
        {

        }

        private void DTBDOR_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string sqlupdate = "update Members set Name='"+txtname.Text+"',Address='"+txtaddress.Text+"',DOB='"+ DTPDOB.Text + "',DOR='"+DTPDOR.Text+"'where MemberID='"+txtID.Text+"'";
                com = new SqlCommand(sqlupdate,con);
                com.ExecuteNonQuery();
                MessageBox.Show(sqlupdate);

                txtID.Clear();
                txtname.Clear();
                txtaddress.Clear();
                DTPDOB.Text = "";
                DTPDOR.Text = "";
                txtID.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in the updating process!"+ex);

                txtID.Clear();
                txtname.Clear();
                txtaddress.Clear();
                DTPDOB.Text = "";
                DTPDOR.Text = "";
                txtID.Focus();

            }
            finally
            {
                con.Close();
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {

            try
            {
                con.Open();
                string sqldelete = "delete from Members where MemberID='" + txtID.Text + "'";
                com = new SqlCommand(sqldelete, con);
                com.ExecuteNonQuery();
                MessageBox.Show("Record deleted successfully!");

                txtID.Clear();
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record Not Found!"+ex);
                txtID.Clear();
                txtID.Focus();
            }
            finally
            {
                con.Close();
            }
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string ID = txtsearch.Text;
                string sqlsearch = "SELECT* FROM Members WHERE MemberID='" + txtsearch.Text + "'";
                com = new SqlCommand(sqlsearch, con);
                SqlDataReader s = com.ExecuteReader();
                while (s.Read()) 
                {
                    txtID.Text = s[0].ToString();
                    txtname.Text = s[1].ToString();
                    txtaddress.Text = s[2].ToString();
                    DTPDOB.Text = s[3].ToString();
                    DTPDOR.Text = s[4].ToString();
                }
            }
            catch (Exception ex )
            {
                MessageBox.Show("There's no member registered under this Member ID"+ex);
                txtsearch.Clear();
                txtsearch.Focus();
            }
            finally
            {
                con.Close();
            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
