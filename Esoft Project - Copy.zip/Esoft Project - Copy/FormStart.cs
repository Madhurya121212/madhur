﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3library
{
    public partial class FrmStart : Form
    {
        public FrmStart()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'lMSDataSettest.Books' table. You can move, or remove it, as needed.
            this.booksTableAdapter.Fill(this.lMSDataSettest.Books);

        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome","Greetings!",MessageBoxButtons.OK);
            Frmlogin login = new Frmlogin();
            this.Hide();
            login.Show();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
