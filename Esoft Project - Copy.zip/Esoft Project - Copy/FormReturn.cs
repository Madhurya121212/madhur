﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3library
{
    public partial class Frmbr : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\LMS.mdf;Integrated Security = True");
        SqlCommand com;
        public Frmbr()
        {
            InitializeComponent();
        }

        private void Frmbr_Load(object sender, EventArgs e)
        {

        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string ID = txtsearch.Text;
                string sqlsearch = "SELECT* FROM IB WHERE Id='" + txtsearch.Text + "'";
                SqlCommand com = new SqlCommand(sqlsearch, con);
                SqlDataReader r = com.ExecuteReader();
                if (r.Read())
                {

                    txtsearch.Text = r[0].ToString();
                    dtpb.Text = r[1].ToString();
                    dtpr.Text = r[2].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("A book hasn't been borrowed under this Member ID"+ex);

                txtsearch.Clear();
                dtpb.Text = "";
                dtpr.Text = "";
                txtsearch.Focus();
            }
            finally
            {
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string sqldelete = "delete from IB where Id='" + txtsearch.Text + "'";
                com = new SqlCommand(sqldelete, con);
                com.ExecuteNonQuery();
                MessageBox.Show("Book Returned");

                txtsearch.Clear();
                dtpb.Text = "";
                dtpr.Text = "";
                txtsearch.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show("A book hasn't been borrowed under this Member ID"+ex);
                txtsearch.Clear();
                txtsearch.Focus();

            }
            finally
            {
                con.Close();
            }
        }
    }
}
