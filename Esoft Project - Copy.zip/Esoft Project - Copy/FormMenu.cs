﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using System.Data.SqlClient;

namespace WindowsFormsApp3library
{
    public partial class Frmmenuma : Form
    {
        public Frmmenuma()
        {
            InitializeComponent();
        }

        private void novelsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void registerToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void Frmmenu_Load(object sender, EventArgs e)
        {

        }

        private void Frmmenu_Load_1(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem5_Click(object sender, EventArgs e)
        {
          Frmmember frmmember = new Frmmember();
            frmmember.MdiParent = this;
            frmmember.Show();
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            Frmmember frmmember = new Frmmember();
            frmmember.MdiParent = this;
            frmmember.Show();
        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            Frmmember frmmember = new Frmmember();
            frmmember.MdiParent = this;
            frmmember.Show();
        }

        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {
            Frmmember frmmember = new Frmmember();
            frmmember.MdiParent = this;
            frmmember.Show();
        }

        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            Frmbooks frmbooks = new Frmbooks();
            frmbooks.MdiParent = this;
            frmbooks.Show();
        }

        private void updareToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frmbooks frmbooks = new Frmbooks();
            frmbooks.MdiParent = this;
            frmbooks.Show();
        }

        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {
            Frmbooks frmbooks = new Frmbooks();
            frmbooks.MdiParent = this;
            frmbooks.Show();
        }

        private void toolStripMenuItem11_Click(object sender, EventArgs e)
        {
            Frmbooks frmbooks = new Frmbooks();
            frmbooks.MdiParent = this;
            frmbooks.Show();
        }

        private void calculatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frmcal frmcal = new Frmcal();
            frmcal.MdiParent = this;
            frmcal.Show();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Logging out", "Continuing", MessageBoxButtons.OK , MessageBoxIcon.Asterisk);
            Frmlogout logout = new Frmlogout();
            this.Hide();
            logout.Show();
        }

        private void borrowBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frmbi frmborrow = new Frmbi();
            frmborrow.MdiParent = this;
            frmborrow.Show();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void returnBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frmbr frmreturn = new Frmbr();
            frmreturn.MdiParent = this;
            frmreturn.Show();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void testToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frmbooks frmbooks = new Frmbooks();
            frmbooks.MdiParent = this;
            frmbooks.Show();
        }
    }
}
