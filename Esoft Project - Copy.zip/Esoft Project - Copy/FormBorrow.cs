﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3library
{
    public partial class Frmbi : Form
    {//Data Source = (LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\LMS.mdf;Integrated Security = True
        SqlConnection con = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\LMS.mdf;Integrated Security = True");
        SqlCommand com;
        public Frmbi()
        {
            InitializeComponent();
        }

        private void btnissue_Click(object sender, EventArgs e)
        {
                try
                {
                    con.Open();
                string sqlinsert = "insert into IB(Id,DOB,DOR)values('" + txtmid.Text + "','" + dtpbb.Text + "','" + dtprb.Text + "')";
                    com = new SqlCommand(sqlinsert, con);
                    com.ExecuteNonQuery();
                    MessageBox.Show("Book Issued");

                txtbid.Clear();
                txtbn.Clear();
                txtmid.Clear();
                txtmn.Clear();
                dtprb.Text = "";
                dtprb.Text = "";
                }
                catch (Exception ex)
                {
                MessageBox.Show("A book is already issued under this Member ID!"+ex);
               
                    

                txtbid.Clear();
                txtbn.Clear();
                txtmid.Clear();
                txtmn.Clear();
                dtprb.Text = "";
                dtprb.Text = "";
          
                 }
                finally
                {
                    con.Close();
                }
        }

        private void btnmid_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string ID = txtmid.Text;
                string sqlsearch = "SELECT Name FROM Members WHERE MemberID='" + txtmid.Text + "'";
                SqlCommand com = new SqlCommand(sqlsearch, con);
                SqlDataReader s = com.ExecuteReader();
                if (s.Read())
                {
                    txtmn.Text = s["Name"].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record Not Found!"+ex);
                txtmid.Clear();
                txtmid.Focus();
            }
            finally
            {
                con.Close();
            }
        }

        private void txtmid_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnbid_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string ID = txtbid.Text;
                string sqlsearch = "SELECT BookName FROM Books WHERE BookID='" + txtbid.Text + "'";
                SqlCommand com = new SqlCommand(sqlsearch, con);
                SqlDataReader r = com.ExecuteReader();
                if (r.Read())
                {
                    txtbn.Text = r["BookName"].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Record Not Found!"+ex);
                txtbid.Clear();
                txtbid.Focus();
            }
            finally
            {
                con.Close();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Frmbi_Load(object sender, EventArgs e)
        {

        }
    }
}
