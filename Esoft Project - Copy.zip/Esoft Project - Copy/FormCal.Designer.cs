﻿
namespace WindowsFormsApp3library
{
    partial class Frmcal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frmcal));
            this.Days = new System.Windows.Forms.Label();
            this.Fine = new System.Windows.Forms.Label();
            this.txtnodays = new System.Windows.Forms.TextBox();
            this.txtfine = new System.Windows.Forms.TextBox();
            this.Totfine = new System.Windows.Forms.Label();
            this.txttotfine = new System.Windows.Forms.TextBox();
            this.btnclear = new System.Windows.Forms.Button();
            this.btntotal = new System.Windows.Forms.Button();
            this.btnback = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Days
            // 
            this.Days.AutoSize = true;
            this.Days.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Days.Location = new System.Drawing.Point(36, 78);
            this.Days.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Days.Name = "Days";
            this.Days.Size = new System.Drawing.Size(180, 25);
            this.Days.TabIndex = 0;
            this.Days.Text = "Number of Days";
            this.Days.Click += new System.EventHandler(this.label3_Click);
            // 
            // Fine
            // 
            this.Fine.AutoSize = true;
            this.Fine.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Fine.Location = new System.Drawing.Point(37, 194);
            this.Fine.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Fine.Name = "Fine";
            this.Fine.Size = new System.Drawing.Size(144, 25);
            this.Fine.TabIndex = 1;
            this.Fine.Text = "Fine Amount";
            this.Fine.Click += new System.EventHandler(this.Fine_Click);
            // 
            // txtnodays
            // 
            this.txtnodays.Location = new System.Drawing.Point(429, 78);
            this.txtnodays.Margin = new System.Windows.Forms.Padding(4);
            this.txtnodays.Name = "txtnodays";
            this.txtnodays.Size = new System.Drawing.Size(212, 22);
            this.txtnodays.TabIndex = 2;
            // 
            // txtfine
            // 
            this.txtfine.Location = new System.Drawing.Point(429, 194);
            this.txtfine.Margin = new System.Windows.Forms.Padding(4);
            this.txtfine.Name = "txtfine";
            this.txtfine.Size = new System.Drawing.Size(212, 22);
            this.txtfine.TabIndex = 3;
            // 
            // Totfine
            // 
            this.Totfine.AutoSize = true;
            this.Totfine.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Totfine.Location = new System.Drawing.Point(49, 305);
            this.Totfine.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Totfine.Name = "Totfine";
            this.Totfine.Size = new System.Drawing.Size(118, 25);
            this.Totfine.TabIndex = 4;
            this.Totfine.Text = "Total Fine";
            this.Totfine.Click += new System.EventHandler(this.Totfine_Click);
            // 
            // txttotfine
            // 
            this.txttotfine.Location = new System.Drawing.Point(429, 305);
            this.txttotfine.Margin = new System.Windows.Forms.Padding(4);
            this.txttotfine.Name = "txttotfine";
            this.txttotfine.Size = new System.Drawing.Size(212, 22);
            this.txttotfine.TabIndex = 5;
            // 
            // btnclear
            // 
            this.btnclear.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.btnclear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclear.Location = new System.Drawing.Point(299, 395);
            this.btnclear.Margin = new System.Windows.Forms.Padding(4);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(94, 46);
            this.btnclear.TabIndex = 6;
            this.btnclear.Text = "Clear";
            this.btnclear.UseVisualStyleBackColor = false;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // btntotal
            // 
            this.btntotal.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.btntotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntotal.Location = new System.Drawing.Point(56, 405);
            this.btntotal.Margin = new System.Windows.Forms.Padding(4);
            this.btntotal.Name = "btntotal";
            this.btntotal.Size = new System.Drawing.Size(94, 46);
            this.btntotal.TabIndex = 7;
            this.btntotal.Text = "Total";
            this.btntotal.UseVisualStyleBackColor = false;
            this.btntotal.Click += new System.EventHandler(this.btntotal_Click);
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.btnback.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.Location = new System.Drawing.Point(567, 395);
            this.btnback.Margin = new System.Windows.Forms.Padding(4);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(74, 46);
            this.btnback.TabIndex = 9;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // Frmcal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(674, 537);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.btntotal);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.txttotfine);
            this.Controls.Add(this.Totfine);
            this.Controls.Add(this.txtfine);
            this.Controls.Add(this.txtnodays);
            this.Controls.Add(this.Fine);
            this.Controls.Add(this.Days);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Frmcal";
            this.Text = "Fine Calculator";
            this.Load += new System.EventHandler(this.Frmcal_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Days;
        private System.Windows.Forms.Label Fine;
        private System.Windows.Forms.TextBox txtnodays;
        private System.Windows.Forms.TextBox txtfine;
        private System.Windows.Forms.Label Totfine;
        private System.Windows.Forms.TextBox txttotfine;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.Button btntotal;
        private System.Windows.Forms.Button btnback;
    }
}