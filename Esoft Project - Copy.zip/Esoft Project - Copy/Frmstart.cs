﻿using System.Windows.Forms;

namespace WindowsFormsApp3library
{
    internal class Frmstart : Form
    {
    }
}