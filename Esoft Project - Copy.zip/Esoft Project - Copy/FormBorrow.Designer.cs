﻿
namespace WindowsFormsApp3library
{
    partial class Frmbi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frmbi));
            this.mn = new System.Windows.Forms.Label();
            this.bn = new System.Windows.Forms.Label();
            this.doi = new System.Windows.Forms.Label();
            this.dor = new System.Windows.Forms.Label();
            this.btnmid = new System.Windows.Forms.Button();
            this.btnbid = new System.Windows.Forms.Button();
            this.txtmid = new System.Windows.Forms.TextBox();
            this.txtbn = new System.Windows.Forms.TextBox();
            this.txtbid = new System.Windows.Forms.TextBox();
            this.txtmn = new System.Windows.Forms.TextBox();
            this.dtpbb = new System.Windows.Forms.DateTimePicker();
            this.dtprb = new System.Windows.Forms.DateTimePicker();
            this.btnissue = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // mn
            // 
            this.mn.AutoSize = true;
            this.mn.Font = new System.Drawing.Font("Lucida Bright", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mn.Location = new System.Drawing.Point(543, 79);
            this.mn.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.mn.Name = "mn";
            this.mn.Size = new System.Drawing.Size(125, 18);
            this.mn.TabIndex = 0;
            this.mn.Text = "Member Name";
            // 
            // bn
            // 
            this.bn.AutoSize = true;
            this.bn.Font = new System.Drawing.Font("Lucida Bright", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bn.Location = new System.Drawing.Point(543, 191);
            this.bn.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bn.Name = "bn";
            this.bn.Size = new System.Drawing.Size(96, 17);
            this.bn.TabIndex = 1;
            this.bn.Text = "Book Name";
            // 
            // doi
            // 
            this.doi.AutoSize = true;
            this.doi.Font = new System.Drawing.Font("Lucida Bright", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doi.Location = new System.Drawing.Point(44, 306);
            this.doi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.doi.Name = "doi";
            this.doi.Size = new System.Drawing.Size(222, 17);
            this.doi.TabIndex = 2;
            this.doi.Text = "Date of Borrowing the Book";
            // 
            // dor
            // 
            this.dor.AutoSize = true;
            this.dor.Font = new System.Drawing.Font("Lucida Bright", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dor.Location = new System.Drawing.Point(543, 297);
            this.dor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.dor.Name = "dor";
            this.dor.Size = new System.Drawing.Size(216, 17);
            this.dor.TabIndex = 3;
            this.dor.Text = "Date of Returning the Book";
            // 
            // btnmid
            // 
            this.btnmid.Font = new System.Drawing.Font("Lucida Bright", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmid.Location = new System.Drawing.Point(47, 67);
            this.btnmid.Margin = new System.Windows.Forms.Padding(4);
            this.btnmid.Name = "btnmid";
            this.btnmid.Size = new System.Drawing.Size(244, 30);
            this.btnmid.TabIndex = 4;
            this.btnmid.Text = "Search Member ID";
            this.btnmid.UseVisualStyleBackColor = true;
            this.btnmid.Click += new System.EventHandler(this.btnmid_Click);
            // 
            // btnbid
            // 
            this.btnbid.Font = new System.Drawing.Font("Lucida Bright", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbid.Location = new System.Drawing.Point(47, 187);
            this.btnbid.Margin = new System.Windows.Forms.Padding(4);
            this.btnbid.Name = "btnbid";
            this.btnbid.Size = new System.Drawing.Size(244, 30);
            this.btnbid.TabIndex = 5;
            this.btnbid.Text = "Search Book ID";
            this.btnbid.UseVisualStyleBackColor = true;
            this.btnbid.Click += new System.EventHandler(this.btnbid_Click);
            // 
            // txtmid
            // 
            this.txtmid.Font = new System.Drawing.Font("Lucida Bright", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmid.Location = new System.Drawing.Point(308, 71);
            this.txtmid.Margin = new System.Windows.Forms.Padding(4);
            this.txtmid.Name = "txtmid";
            this.txtmid.Size = new System.Drawing.Size(148, 25);
            this.txtmid.TabIndex = 6;
            this.txtmid.TextChanged += new System.EventHandler(this.txtmid_TextChanged);
            // 
            // txtbn
            // 
            this.txtbn.Font = new System.Drawing.Font("Lucida Bright", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbn.Location = new System.Drawing.Point(703, 183);
            this.txtbn.Margin = new System.Windows.Forms.Padding(4);
            this.txtbn.Name = "txtbn";
            this.txtbn.Size = new System.Drawing.Size(370, 25);
            this.txtbn.TabIndex = 7;
            // 
            // txtbid
            // 
            this.txtbid.Font = new System.Drawing.Font("Lucida Bright", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbid.Location = new System.Drawing.Point(308, 188);
            this.txtbid.Margin = new System.Windows.Forms.Padding(4);
            this.txtbid.Name = "txtbid";
            this.txtbid.Size = new System.Drawing.Size(148, 25);
            this.txtbid.TabIndex = 8;
            // 
            // txtmn
            // 
            this.txtmn.Font = new System.Drawing.Font("Lucida Bright", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmn.Location = new System.Drawing.Point(703, 71);
            this.txtmn.Margin = new System.Windows.Forms.Padding(4);
            this.txtmn.Name = "txtmn";
            this.txtmn.Size = new System.Drawing.Size(370, 25);
            this.txtmn.TabIndex = 9;
            // 
            // dtpbb
            // 
            this.dtpbb.Font = new System.Drawing.Font("Lucida Bright", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpbb.Location = new System.Drawing.Point(276, 369);
            this.dtpbb.Margin = new System.Windows.Forms.Padding(4);
            this.dtpbb.Name = "dtpbb";
            this.dtpbb.Size = new System.Drawing.Size(298, 25);
            this.dtpbb.TabIndex = 10;
            // 
            // dtprb
            // 
            this.dtprb.Font = new System.Drawing.Font("Lucida Bright", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtprb.Location = new System.Drawing.Point(703, 369);
            this.dtprb.Margin = new System.Windows.Forms.Padding(4);
            this.dtprb.Name = "dtprb";
            this.dtprb.Size = new System.Drawing.Size(298, 25);
            this.dtprb.TabIndex = 11;
            // 
            // btnissue
            // 
            this.btnissue.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnissue.Font = new System.Drawing.Font("Lucida Bright", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnissue.Location = new System.Drawing.Point(519, 420);
            this.btnissue.Margin = new System.Windows.Forms.Padding(4);
            this.btnissue.Name = "btnissue";
            this.btnissue.Size = new System.Drawing.Size(222, 67);
            this.btnissue.TabIndex = 12;
            this.btnissue.Text = "Issue Book ";
            this.btnissue.UseVisualStyleBackColor = false;
            this.btnissue.Click += new System.EventHandler(this.btnissue_Click);
            // 
            // Frmbi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1242, 589);
            this.Controls.Add(this.btnissue);
            this.Controls.Add(this.dtprb);
            this.Controls.Add(this.dtpbb);
            this.Controls.Add(this.txtmn);
            this.Controls.Add(this.txtbid);
            this.Controls.Add(this.txtbn);
            this.Controls.Add(this.txtmid);
            this.Controls.Add(this.btnbid);
            this.Controls.Add(this.btnmid);
            this.Controls.Add(this.dor);
            this.Controls.Add(this.doi);
            this.Controls.Add(this.bn);
            this.Controls.Add(this.mn);
            this.Font = new System.Drawing.Font("Lucida Bright", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Frmbi";
            this.Text = "Borrow Books";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Frmbi_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label mn;
        private System.Windows.Forms.Label bn;
        private System.Windows.Forms.Label doi;
        private System.Windows.Forms.Label dor;
        private System.Windows.Forms.Button btnmid;
        private System.Windows.Forms.Button btnbid;
        private System.Windows.Forms.TextBox txtmid;
        private System.Windows.Forms.TextBox txtbn;
        private System.Windows.Forms.TextBox txtbid;
        private System.Windows.Forms.TextBox txtmn;
        private System.Windows.Forms.DateTimePicker dtpbb;
        private System.Windows.Forms.DateTimePicker dtprb;
        private System.Windows.Forms.Button btnissue;
    }
}