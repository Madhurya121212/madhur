﻿
namespace WindowsFormsApp3library
{
    partial class Frmmember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frmmember));
            this.MID = new System.Windows.Forms.Label();
            this.Mname = new System.Windows.Forms.Label();
            this.Maddress = new System.Windows.Forms.Label();
            this.MDOB = new System.Windows.Forms.Label();
            this.MDOR = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.DTPDOB = new System.Windows.Forms.DateTimePicker();
            this.DTPDOR = new System.Windows.Forms.DateTimePicker();
            this.btnregister = new System.Windows.Forms.Button();
            this.btnclearall = new System.Windows.Forms.Button();
            this.btnclose = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btnsearch = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.txtsearch = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // MID
            // 
            this.MID.AutoSize = true;
            this.MID.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MID.Location = new System.Drawing.Point(53, 25);
            this.MID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MID.Name = "MID";
            this.MID.Size = new System.Drawing.Size(80, 18);
            this.MID.TabIndex = 0;
            this.MID.Text = "Member ID";
            this.MID.Click += new System.EventHandler(this.label1_Click);
            // 
            // Mname
            // 
            this.Mname.AutoSize = true;
            this.Mname.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mname.Location = new System.Drawing.Point(53, 97);
            this.Mname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Mname.Name = "Mname";
            this.Mname.Size = new System.Drawing.Size(49, 18);
            this.Mname.TabIndex = 1;
            this.Mname.Text = "Name";
            this.Mname.Click += new System.EventHandler(this.label2_Click);
            // 
            // Maddress
            // 
            this.Maddress.AutoSize = true;
            this.Maddress.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Maddress.Location = new System.Drawing.Point(53, 171);
            this.Maddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Maddress.Name = "Maddress";
            this.Maddress.Size = new System.Drawing.Size(60, 18);
            this.Maddress.TabIndex = 2;
            this.Maddress.Text = "Address";
            this.Maddress.Click += new System.EventHandler(this.label3_Click);
            // 
            // MDOB
            // 
            this.MDOB.AutoSize = true;
            this.MDOB.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MDOB.Location = new System.Drawing.Point(53, 261);
            this.MDOB.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MDOB.Name = "MDOB";
            this.MDOB.Size = new System.Drawing.Size(93, 18);
            this.MDOB.TabIndex = 3;
            this.MDOB.Text = "Date of Birth";
            this.MDOB.Click += new System.EventHandler(this.label4_Click);
            // 
            // MDOR
            // 
            this.MDOR.AutoSize = true;
            this.MDOR.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MDOR.Location = new System.Drawing.Point(53, 350);
            this.MDOR.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.MDOR.Name = "MDOR";
            this.MDOR.Size = new System.Drawing.Size(139, 18);
            this.MDOR.TabIndex = 4;
            this.MDOR.Text = "Date of Registration";
            this.MDOR.Click += new System.EventHandler(this.label5_Click);
            // 
            // txtID
            // 
            this.txtID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtID.Location = new System.Drawing.Point(358, 12);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(155, 22);
            this.txtID.TabIndex = 5;
            this.txtID.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtaddress
            // 
            this.txtaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaddress.Location = new System.Drawing.Point(358, 167);
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(326, 22);
            this.txtaddress.TabIndex = 6;
            this.txtaddress.TextChanged += new System.EventHandler(this.txtaddress_TextChanged);
            // 
            // txtname
            // 
            this.txtname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(358, 93);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(326, 22);
            this.txtname.TabIndex = 7;
            this.txtname.TextChanged += new System.EventHandler(this.txtname_TextChanged);
            // 
            // DTPDOB
            // 
            this.DTPDOB.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DTPDOB.Location = new System.Drawing.Point(358, 261);
            this.DTPDOB.Name = "DTPDOB";
            this.DTPDOB.Size = new System.Drawing.Size(326, 25);
            this.DTPDOB.TabIndex = 8;
            this.DTPDOB.ValueChanged += new System.EventHandler(this.DTPDOB_ValueChanged);
            // 
            // DTPDOR
            // 
            this.DTPDOR.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DTPDOR.Location = new System.Drawing.Point(358, 350);
            this.DTPDOR.Name = "DTPDOR";
            this.DTPDOR.Size = new System.Drawing.Size(326, 25);
            this.DTPDOR.TabIndex = 9;
            this.DTPDOR.ValueChanged += new System.EventHandler(this.DTBDOR_ValueChanged);
            // 
            // btnregister
            // 
            this.btnregister.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnregister.Location = new System.Drawing.Point(328, 426);
            this.btnregister.Name = "btnregister";
            this.btnregister.Size = new System.Drawing.Size(136, 37);
            this.btnregister.TabIndex = 10;
            this.btnregister.Text = "Register";
            this.btnregister.UseVisualStyleBackColor = true;
            this.btnregister.Click += new System.EventHandler(this.btninsert_Click);
            // 
            // btnclearall
            // 
            this.btnclearall.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclearall.Location = new System.Drawing.Point(322, 506);
            this.btnclearall.Name = "btnclearall";
            this.btnclearall.Size = new System.Drawing.Size(142, 27);
            this.btnclearall.TabIndex = 11;
            this.btnclearall.Text = "Clear All";
            this.btnclearall.UseVisualStyleBackColor = true;
            this.btnclearall.Click += new System.EventHandler(this.btnclearall_Click);
            // 
            // btnclose
            // 
            this.btnclose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclose.Location = new System.Drawing.Point(548, 506);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(136, 27);
            this.btnclose.TabIndex = 12;
            this.btnclose.Text = "Close";
            this.btnclose.UseVisualStyleBackColor = true;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.Location = new System.Drawing.Point(542, 426);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(142, 29);
            this.btnupdate.TabIndex = 13;
            this.btnupdate.Text = "Update";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnsearch
            // 
            this.btnsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearch.Location = new System.Drawing.Point(72, 418);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(135, 62);
            this.btnsearch.TabIndex = 14;
            this.btnsearch.Text = "Search by Member ID";
            this.btnsearch.UseVisualStyleBackColor = true;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // btndelete
            // 
            this.btndelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndelete.Location = new System.Drawing.Point(72, 506);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(136, 27);
            this.btndelete.TabIndex = 15;
            this.btndelete.Text = "Delete";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // txtsearch
            // 
            this.txtsearch.Location = new System.Drawing.Point(213, 436);
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(100, 27);
            this.txtsearch.TabIndex = 16;
            this.txtsearch.TextChanged += new System.EventHandler(this.txtsearch_TextChanged);
            // 
            // Frmmember
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(780, 592);
            this.Controls.Add(this.txtsearch);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btnclose);
            this.Controls.Add(this.btnclearall);
            this.Controls.Add(this.btnregister);
            this.Controls.Add(this.DTPDOR);
            this.Controls.Add(this.DTPDOB);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.txtaddress);
            this.Controls.Add(this.txtID);
            this.Controls.Add(this.MDOR);
            this.Controls.Add(this.MDOB);
            this.Controls.Add(this.Maddress);
            this.Controls.Add(this.Mname);
            this.Controls.Add(this.MID);
            this.Font = new System.Drawing.Font("Berlin Sans FB", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Frmmember";
            this.Text = "Members";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Frmmember_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label MID;
        private System.Windows.Forms.Label Mname;
        private System.Windows.Forms.Label Maddress;
        private System.Windows.Forms.Label MDOB;
        private System.Windows.Forms.Label MDOR;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.DateTimePicker DTPDOB;
        private System.Windows.Forms.DateTimePicker DTPDOR;
        private System.Windows.Forms.Button btnregister;
        private System.Windows.Forms.Button btnclearall;
        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.TextBox txtsearch;
    }
}